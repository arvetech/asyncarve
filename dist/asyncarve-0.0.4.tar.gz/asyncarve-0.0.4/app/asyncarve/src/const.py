HOST = "dashboard.arveair.com"
PORT = 3001

HOST_LOCAL = "localhost"
PORT_LOCAL = 3000

